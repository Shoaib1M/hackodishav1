# 🗑 Waste Classification

##  Installation Steps(requirements)
```
  waste-classification/
  ├── app.py
  ├── helper.py
  ├── settings.py
  ├── images/
  │   ├── def.jfif
  │   └── def1.jpg
  ├── weights/
  │   └── yolov8.pt
  ├── requirements.txt
  └── README.md

  streamlit
  ultralytics
  opencv-python-headless
  pafy
  youtube-dl
  Pillow
  To install from this file, run:

  bash
  Copy code
  pip install -r requirements.txt

'''
##  How To Run 
  Open your terminal or command prompt.

  Navigate to the project directory.

  Run:

  bash
  Copy code
  streamlit run app.py
  The app should open automatically in your default web browser at http://localhost:8501.

```